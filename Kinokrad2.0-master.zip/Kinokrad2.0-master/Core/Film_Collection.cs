﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core
{
    public class Film_Collection
    {
        public int ID_FC { get; set; }
        public int ID_Film { get; set; }
        public int ID_Collection { get; set; }
        public DateTime Date { get; set; }

    }
}
