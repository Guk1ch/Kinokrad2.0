﻿using System;
using System.Collections.Generic;
using System.Text;
using Dapper;
using System.Configuration;


namespace Core
{
    public class Collection
    {
        public int ID_Collection { get; set; } // Обязательно исправить: публичные поля класса (Мясников) 
        public string Name { get; set; }
    }
}
