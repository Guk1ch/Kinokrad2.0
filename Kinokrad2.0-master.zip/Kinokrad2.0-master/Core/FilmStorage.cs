﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core
{
    class FilmStorage   //Исправить обязательно: Пустой класс :: Мясников
    {
    }
}
